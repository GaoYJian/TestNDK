*******************
   API Reference
*******************

.. toctree::
   :maxdepth: 1

   ZBarImage
   ZBarImageScanner
   ZBarReaderController
   ZBarReaderDelegate
   ZBarReaderView
   ZBarReaderViewController
   ZBarReaderViewDelegate
   ZBarSymbol
   ZBarSymbolSet
