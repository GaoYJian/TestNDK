zbar
====

zbar source from http://zbar.hg.sourceforge.net/hgweb/zbar/zbar/